DUnit examples:

ChecklessTests 	Demo use and effect of added GUI option "Fail Test If No Checks Executed"
cmdline 	Examples of how to invoke DUnit from the command line
collection 	A Java-like collections implementation and its DUnit test cases
HaltRepeating 	Demo of new ability for repeating tests to halt count when testcase error occurs.
embeddable 	Shows how to embed the GUITestRunner in another tool's forms.
MemLeakDetect 	Demo of new ability to show TestCases (Setup, Run, TearDown) whick leak Memory.
registration 	Using the test case registration system
registry 	A step by step example of building a registry utility, with test cases
structure 	Alternative ways to organize tests
testexception 	Shows two ways to test for expected exceptions
TListTest 	Test cases for the Delphi Classes.TList object 
